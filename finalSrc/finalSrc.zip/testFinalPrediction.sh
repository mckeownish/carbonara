ScatterFile=1LYZSAXSTest.dat
SequenceFile=
initialCoordsFile=no_initial_prediction
pairedPredictions=none
fixedsections=none
crystalSymmetry=none
withinMonomerHydroCover=none
betweenMonomerHydroCover=none
kmin=0.0;
kmax=0.45;


