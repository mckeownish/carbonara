#!/bin/bash
 ScatterFile=/Users/hayden_fisher/Documents/Carbonara_Dressing-master/newFitData/01_62mer/Saxs.dat
 fileLocs=/Users/hayden_fisher/Documents/Carbonara_Dressing-master/newFitData/01_62mer/
 initialCoordsFile=frompdb
 noStructures=1
 pairedPredictions=True
 fixedsections=/Users/hayden_fisher/Documents/Carbonara_Dressing-master/newFitData/01_62mer/varyingSectionSecondary1.dat
 withinMonomerHydroCover=none
 betweenMonomerHydroCover=none
 kmin=0.01
 kmax=0.2
 maxNoFitSteps=50000
 affineTrans=True
for i in {1..1}

do

   echo " Run number : $i "

   ./predictStructureQvary $ScatterFile $fileLocs $initialCoordsFile $pairedPredictions $fixedsections $noStructures $withinMonomerHydroCover $betweenMonomerHydroCover $kmin $kmax $maxNoFitSteps /Users/hayden_fisher/Documents/Carbonara_Dressing-master/newFitData/01_62mer/01_62mer/mol$i /Users/hayden_fisher/Documents/Carbonara_Dressing-master/newFitData/01_62mer/01_62mer/scatter$i.dat /Users/hayden_fisher/Documents/Carbonara_Dressing-master/newFitData/01_62mer/mixtureFile.dat /Users/hayden_fisher/Documents/Carbonara_Dressing-master/newFitData/01_62mer/redundant /Users/hayden_fisher/Documents/Carbonara_Dressing-master/newFitData/01_62mer/01_62mer/fitLog$i.dat null $affineTrans

done
